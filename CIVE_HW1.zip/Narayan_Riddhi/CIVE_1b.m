for j=1:10
    yrw(j,1)=normrnd(0,1);
    time(1)=0;
    for i=2:1000
        time(i)=time(i-1)+1;
        xex(j,i)=0.2*exp(time(i)/100);
        yrw(j,i)=yrw(j,i-1)+normrnd(0,j);
    end 
    zlexrw = 0.1*xex + yrw; 
    %Plotting each contaminated time series separately in one figure.
    figure(1)
    subplot(2,5,j)
    plot(zlexrw(j,:))
end
%Plotting the first exponential signal and all 20 exp signals combined. 
figure(2)
subplot(221)
plot(xex(1,:))
subplot(222)
plot(xex')

%plotting all 10 contaminated time series in one 
figure(3)
zlexrwtot = 0.1*xex' + yrw';
plot(zlexrwtot) 

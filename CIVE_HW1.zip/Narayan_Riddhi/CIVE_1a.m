a = 1;
for j=1:10
    ywn =normrnd(0,a,1,1000);
    time(1)=0;
    for i=2:1000
        time(i)=time(i-1)+1;
        xlr(j,i)=0.2+0.3*time(i);
        zlrwn(j,i) = 0.1*xlr(j,i) + normrnd(0,a);
    end 
    %zlrwn = 0.1*xlr + ywn; 
    %Plotting each contaminated time series separately in one figure.
    figure(1)
    subplot(2,5,j)
    plot(zlrwn(j,:))
    a= a+5 ;
end
%Plotting the first linear signal and all 20 linear signals combined. 
figure(2)
subplot(221)
plot(xlr(1,:))
subplot(222)
plot(xlr')
subplot(223)
%Plotting all 10 contaminated time series in one
plot(zlrwn')
 


for j=1:10
    ywn =normrnd(0,j,1,1000);
    time(1)=0;
    for i=2:1000
        time(i)=time(i-1)+1;
        xlr(j,i)=0.2+0.3*time(i);
        %zlrwn = 0.1*xlr + ywn; 
    end 
   
end

zlrwn = 0.1*xlr + ywn; 

x_train = time(1:700);
x_train = x_train';
x_test = time(701:1000);
x_test= x_test';
%linear regression
for i = 1:10
    
    y_train = zlrwn(i,1:700);
    y_test = zlrwn(i, 701:1000);
    y_train = y_train';
    y_test = y_test';
    mdl = fitlm(x_train, y_train);
    y_pred = predict(mdl, x_test);
    MSE1(i) = mse( y_test, y_pred);
  
end 
figure(2)
plot(MSE1)

% feed forward neural net

for i=1:10
    a= zlrwn(:,i)';
    train_y= a(6:900);
    test= a(701:1000);
    net = feedforwardnet(10);
    net=train(net, train_y,train_y);
    y=net(test);
    figure(3)
    %MSE(i)=mse(net,test,y);
    MSE(i)=mse(net,train_xn,train_y);
    %plot(MSE)
    
end

for i= 1:10
       
        std(i)= i;
     
    end
figure    
plot(std, MSE,'m','Linewidth',2)
xlabel('Std')
ylabel('MSE')
grid
title('MSE vs Std. deviation value')






  



